package com.choongang;

public class ConvertToChar {
    public char convertToChar(int num) {
        char result;
        // TODO: 여기에 코드를 작성합니다.
        result = Character.forDigit(num,10);
        //숫자 num 을 문자타입으로 리턴하기 위해 Character 클래스의 forDigit 매서드를 사용함, 그리고 진수 조건이 없기 때문에 10진수로 변환

        //하단의 코드는 수정하지 말아야 합니다.
        return result;
    }
}
