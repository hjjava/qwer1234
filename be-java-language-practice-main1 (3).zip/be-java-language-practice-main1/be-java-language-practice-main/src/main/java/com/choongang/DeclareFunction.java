package com.choongang;

public class DeclareFunction {
    public int multipleBy2(int input) {
        input = input * 2;
        return input;
    }
    //위의 코드는 수정하지 말아야 합니다

    public int devideBy2(int input) {
        // TODO : 첫 번째 인자에 2를 곱하는 함수 multiplyBy2와 비슷하게
        // 첫 번째 인자를 2로 나누는 함수 divideBy2를 선언하세요.
        // 아래 라인에 코드를 작성해주세요.
        input = input / 2;

        //아래의 코드는 수정하지 말아야 합니다
        return input;
    }
}
