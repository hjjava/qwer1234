package com.choongang;

public class PlusRightType {
    public int plusRightType(){
        // TODO : 변수 score에 숫자 100이 할당되도록 하기 코드를 수정하세요.
        int score = 99 + 1; // 해당 부분을 수정해야 합니다.

        //int score = 99 + '1'; 에서 '1'을 유니코드로 받아들여 계산도 가능하다. 99 + 49


        //하단의 코드는 수정하지 말아야 합니다.
        return score;
    }
}
