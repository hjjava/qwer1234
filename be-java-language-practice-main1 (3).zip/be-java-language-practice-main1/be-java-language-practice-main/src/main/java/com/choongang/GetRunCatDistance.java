package com.choongang;

public class GetRunCatDistance {
    public int getRunCatDistance(int speed, int time) {
        int distance;
        // TODO: 속력(speed), 시간(time)이 숫자로 주어졌을 때, 이동한 거리를 변수 distance에 할당하여 리턴하는
        // getRunCatDistance 함수를 작성하세요.
        // speed와 time에 할당되는 값이 달라져도 정확한 distance를 반환해야 합니다.
        // 이 아래 라인에 작성해주세요.
        distance = speed * time;

        //아래의 코드는 수정하지 말아야 합니다
        return distance;
    }
}
