package com.choongang;

public class ConvertToNumber {
    public int convertToNumber(char character) {
        int result;
        // TODO: 여기에 코드를 작성합니다.
       result = Character.getNumericValue(character);
       //character 는 char 타입으로 int 타입으로 바꾸려면 문자를 숫자값으로 변환해주는 메서드인 Character 클래스의 getNumericValue 메서드를 사용하여 변환함

        //하단의 코드는 수정하지 말아야 합니다.
        return result;
    }
}
