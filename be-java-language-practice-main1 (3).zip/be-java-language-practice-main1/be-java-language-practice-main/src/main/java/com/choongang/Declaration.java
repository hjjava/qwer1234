package com.choongang;

public class Declaration {
    // TODO : 키워드 char을 사용하여 변수 course를 선언하세요.
    char course;

}