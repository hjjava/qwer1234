package com.choongang;

public class AssignmentDouble {
    double pi;
    // TODO : 선언되어 있는 변수 pi에 실수 3.14를 할당하세요.
    public void assignment() {
        //코드는 아래 라인에 작성해야 합니다.
        pi = 3.14;

    }
}
