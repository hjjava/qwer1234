package com.choongang;

public class AssignmentInt {
    int num;
    // TODO : 선언되어 있는 변수 num에 정수 100을 할당하세요.
    public void assignment() {
        //코드는 아래 라인에 작성해야 합니다.
        num = 100;

    }
}
