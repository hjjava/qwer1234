package com.choongang;

public class ComputeAverageLengthOfWords2 {
    public int computeAverageLengthOfWords2(String word1, String word2) {
        int result;
        //TODO: 두 단어를 입력받아 두 단어의 평균 길이를 내림하여 할당해야 합니다.
        // 미리 선언된 result 변수에 word1, word2의 평균 길이를 구하고 내림 처리하여 할당하세요.
        result = (word1.length() + word2.length()) / 2;
        // result는 int 타입 정수이기에 소수점 이하를 포함하지 않기 떄문에 굳이 내림 처리할 필요가 없음(?)

        // 아래 코드는 수정하지 말아야 합니다.
        return result;
    }
}
