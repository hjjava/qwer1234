package com.choongang;

public class AssignmentChar {
    char course;
    // TODO : 선언되어 있는 변수 course에 char 타입의 문자 'A'를 할당하세요.
    public void assignment() {
        //코드는 아래 라인에 작성해야 합니다.
        course = 'A';

    }
}
