package com.choongang;

public class CompareOnlyAlphabet {
    public boolean compareOnlyAlphabet(String str1, String str2) {
        boolean result;
        // TODO: str1, str2 두개의 문자열을 대소문자를 구분하지 않고(case insensitive) 서로 같은지 여부를 할당해야 합니다.
        // 같다면 result에 true를, 다르다면 result에 false를 할당해야 합니다.
        String lowerStr1 = str1.toLowerCase();
        String lowerStr2 = str2.toLowerCase();
        result = lowerStr1.equals(lowerStr2);
        // 두 문자열을 둘다 소문자로 변경하기 위해 toLowerCase() 를 사용하여 str1과 str2를 아래처럼 같은 문자로 변경하고, 비교하였다
        // == 연산자는 문자열의 내용을 비교하는 것이 아닌 메모리상의 위치를 비교하기 때문에 boolean 을 따져보면 false 값만 도출된다. 그렇기에 equals() 사용함

        // str1 = str1.toLowerCase();
        // str2 = str2.toLowerCase();
        // result = str1.equals(str2);
        //위와 같이 구했으나 아래 result 값으로 나온 str1과 str2가 소문자로 바꾼 것이 아닌 위의 재할당 되기 전의 것과 혼동이 생겨 String lowerStr1 을 다시 변수 선언 후 변경

        //아래 코드는 수정하지 말아야 합니다.
        return result;
    }
}
