package com.choongang;

public class ComputeDifference {
    public String computeDifference(int num1, int num2) {
        String result;
        //TODO: 두 수를 입력받아 두 수의 차이를 나타내는 메세지를 result에 할당해야 합니다.
        // num1이 3, num2가 7이라면
        // "3, 7의 차이는 4입니다." 라는 문자열을 result에 할당해야 합니다.

        result = String.format("%d, %d의 차이는 %d입니다.", num1, num2, Math.abs(num1 - num2));
        // + 연산자 사용 불가로 String.format() 메서드 사용, 숫자를 입력받기 때문에 %d 기호, 절대값을 구하는 Math.abs() 사용하여 num1 - num2의 절대값 추가

        //아래 코드는 수정하지 말아야 합니다.
        return result;
    }
}
