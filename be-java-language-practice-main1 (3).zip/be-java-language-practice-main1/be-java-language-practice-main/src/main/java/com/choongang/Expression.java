package com.choongang;

public class Expression {
    int num1, num2, result;
    // 변수 num1에 숫자 5를 할당하고, 변수 num2에 숫자 7을 할당한 후, 변수 result에 숫자가 할당된 변수 num1과 num2의 곱을 할당합니다.
    public void expression() {
        //코드는 아래 라인에 작성해야 합니다.
        num1 = 5;
        num2 = 7;
        result = num1 * num2;

    }
}
