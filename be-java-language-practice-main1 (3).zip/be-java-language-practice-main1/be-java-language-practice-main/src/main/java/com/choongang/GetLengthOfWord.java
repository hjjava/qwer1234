package com.choongang;

public class GetLengthOfWord {
    public int getLengthOfWord(String word) {
        int stringLength;
        // TODO: 선언된 stringLength 변수에 입력된 word 문자열의 길이를 할당해야 합니다.
        stringLength = word.length();
        // 선언된 stringLength 에 문자열의 길이를 나타내는 매서드 .length() 사용

        //아래 코드는 수정하지 말아야 합니다.
        return stringLength;
    }
}
