package com.choongang;

public class GetFullName {
    public String getFullName(String firstName, String lastName) {
        String fullName;
        // TODO: 이름과 성을 입력받아 띄어쓰기 하나를 사이에 둔 단일 문자열을 fullName에 할당해야 합니다.
        fullName = firstName + " " + lastName;
        // 공백 문자열은 따로 변수 선언할 필요 없으므로

        // 아래 코드는 수정하지 말아야 합니다.
        return fullName;
    }
}
